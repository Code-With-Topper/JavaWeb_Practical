Practical 8: Custom JSP Tag (shows: Welcome Student)
NetBeans: File > Open Project > select this folder.
First time: Tools > Servers > Add Server > Apache Tomcat 9 (javax). Do NOT use Tomcat 10+.
Right-click project > Properties > Run > choose the Tomcat 9 server.
Right-click project > Run. Browser opens at the link below.
Link: http://localhost:8080/jsp-tag/
