Practical 1: JDBC Login
NetBeans: File > Open Project > select this folder > right-click project > Run.
(or open main class LoginApp.java and press Shift+F6)
MySQL: start the server (user root, empty password). Run schema.sql once:
  NetBeans > Services > Databases > MySQL Server > Connect > right-click "test" > Execute Command (paste schema.sql)
  OR in a terminal: mysql -u root < schema.sql
