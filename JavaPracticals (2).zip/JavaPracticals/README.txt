Java Practicals 1 to 10 (NetBeans / Maven projects)

OPEN IN NETBEANS
1. Unzip.
2. File > Open Project.
3. Select the folder "JavaPracticals" (opens all 10) OR any single practical folder.
4. Right-click a project > Run. (Web ones need Tomcat 9. See their README.)

Needs: JDK 17+, NetBeans 17+, MySQL (practicals 1,2,3,10). MySQL: root, empty password.
Internet is needed the first time. Maven downloads the libraries.
