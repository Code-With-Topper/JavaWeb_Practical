Practical 10: Hibernate (insert record) with MySQL
NetBeans: File > Open Project > select this folder > Run.
MySQL must be running (user root, empty password). Table "student" is made by Hibernate.
Output: Record Inserted
Different password? Edit src/main/resources/hibernate.cfg.xml
Note: Manual code is Hibernate only. Struts 2 is not in it.
