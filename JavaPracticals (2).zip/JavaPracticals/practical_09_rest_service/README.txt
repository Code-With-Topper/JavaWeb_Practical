Practical 9: REST Web Service
NetBeans: File > Open Project > select this folder > Run.
Server starts at http://localhost:8080/api/ . Click in the Output window and press Enter to stop.
Test in a terminal or Postman (POST, body = Rahul):
curl -X POST -H "Content-Type: text/plain" -d "Rahul" http://localhost:8080/api/student/register
Output: Student Registered Successfully
