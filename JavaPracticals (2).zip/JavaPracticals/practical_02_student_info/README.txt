Practical 2: Insert, Update, Delete
NetBeans: File > Open Project > select this folder > right-click project > Run.
(or open main class StudentInfo.java and press Shift+F6)
MySQL: start the server (user root, empty password). Run schema.sql once:
  NetBeans > Services > Databases > MySQL Server > Connect > right-click "test" > Execute Command (paste schema.sql)
  OR in a terminal: mysql -u root < schema.sql
