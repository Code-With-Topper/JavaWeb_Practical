Practical 7: JavaBeans
NetBeans: File > Open Project > select this folder > Run.
Main class: TestBean
