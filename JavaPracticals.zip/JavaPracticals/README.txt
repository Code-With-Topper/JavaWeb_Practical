Java Practicals 1 to 10 (code follows the manual)
How to run any practical:
1. Open its folder.
2. Double-click run.bat (Windows) or run: sh run.sh (Linux/Mac).
3. For web ones (4,5,6,8), open the link in that folder's README.txt.

Install first: JDK 17+, MySQL (for 1,2,3,10), Maven (for 4,5,6,8,9,10).
MySQL: user root, empty password (same as the manual).
