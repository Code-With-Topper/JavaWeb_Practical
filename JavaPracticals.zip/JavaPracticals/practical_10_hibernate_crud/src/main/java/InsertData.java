import org.hibernate.*;

public class InsertData {
    public static void main(String args[]) {
        // Open Hibernate Session
        Session s = HibernateUtil
                .getSessionFactory()
                .openSession();

        // Begin Transaction
        Transaction tx = s.beginTransaction();

        // Create Object
        Student st = new Student();

        // Set values
        st.setName("Rahul");
        st.setRoll(101);

        // Save object
        s.save(st);

        // Commit Transaction
        tx.commit();

        System.out.println("Record Inserted");

        // Close (so the program ends)
        s.close();
        HibernateUtil.getSessionFactory().close();
    }
}
