Practical 10: Hibernate (insert record) with MySQL
Needs: JDK 8+, Maven, MySQL running (user root, empty password).
The table "student" is created by Hibernate. No SQL needed.
Run: double-click run.bat (Windows)  or  sh run.sh (Linux/Mac)
Output: Record Inserted
Check in MySQL: select * from test.student;
Different MySQL password? Change it in src/main/resources/hibernate.cfg.xml
Note: The manual code uses Hibernate only. Struts 2 is not in the manual code.
