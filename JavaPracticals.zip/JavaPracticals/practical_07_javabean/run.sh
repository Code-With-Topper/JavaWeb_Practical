#!/bin/sh
javac BankBean.java TestBean.java && java TestBean
