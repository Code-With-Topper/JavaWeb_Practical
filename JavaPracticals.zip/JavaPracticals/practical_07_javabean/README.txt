Practical 7: JavaBeans
Needs: JDK only.
Run: double-click run.bat  or  sh run.sh
