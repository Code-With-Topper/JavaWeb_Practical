public class TestBean {
    public static void main(String[] args) {
        BankBean b = new BankBean();
        b.setName("Rahul");
        b.setBalance(5000.50);
        System.out.println("Name    : " + b.getName());
        System.out.println("Balance : " + b.getBalance());
    }
}
