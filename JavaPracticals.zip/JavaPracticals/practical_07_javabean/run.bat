@echo off
javac BankBean.java TestBean.java && java TestBean
pause
