import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RedirectServlet extends HttpServlet {
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws ServletException, IOException {
        // Get URL from textbox
        String url = request.getParameter("location");

        // Redirect user
        response.sendRedirect(url);

        // Commission Calculation
        double sale = 50000;
        double commission = sale * 0.10;
        System.out.println("Commission = " + commission);
    }
}
