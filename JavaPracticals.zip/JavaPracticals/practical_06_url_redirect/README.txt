Practical 6: URL Redirection
Needs: JDK 8+ and Maven.
Run: double-click run.bat (Windows)  or  sh run.sh (Linux/Mac)
Open: http://localhost:8080/redirect-servlet/
Type the full URL, like https://www.google.com
Commission (5000.0) prints in the run window.
Stop: Ctrl+C
