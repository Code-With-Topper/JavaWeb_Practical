Practical 9: REST Web Service
Needs: JDK 8+ and Maven.
Run: double-click run.bat  or  sh run.sh
Test in a new terminal:
curl -X POST -H "Content-Type: text/plain" -d "Rahul" http://localhost:8080/api/student/register
Stop: press Enter in the run window.
