import java.net.URI;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

public class MainApp {
    public static void main(String[] args) throws Exception {
        URI base = URI.create("http://localhost:8080/api/");
        HttpServer server = GrizzlyHttpServerFactory.createHttpServer(
                base, new ResourceConfig(StudentService.class));
        System.out.println("Server running at " + base);
        System.out.println("Press Enter to stop.");
        System.in.read();
        server.shutdownNow();
    }
}
