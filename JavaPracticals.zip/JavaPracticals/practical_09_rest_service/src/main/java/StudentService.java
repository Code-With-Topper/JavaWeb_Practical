import javax.ws.rs.*;

@Path("/student")
public class StudentService {

    @POST
    @Path("/register")
    public String registerStudent(String name) {
        // Return success message
        return "Student Registered Successfully";
    }
}
