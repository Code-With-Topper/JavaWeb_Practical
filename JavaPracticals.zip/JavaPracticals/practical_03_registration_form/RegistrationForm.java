import javax.swing.*; // Import Swing package
import java.awt.event.*; // Import event package
import java.sql.*; // Import SQL package

public class RegistrationForm {
    public static void main(String args[]) {
        // Create Frame
        JFrame f = new JFrame("Registration Form");

        // Create Labels
        JLabel l1 = new JLabel("Name");
        JLabel l2 = new JLabel("Email");

        // Create TextFields
        JTextField t1 = new JTextField();
        JTextField t2 = new JTextField();

        // Create Button
        JButton b = new JButton("Submit");

        // Set Bounds
        l1.setBounds(50, 50, 100, 30);
        t1.setBounds(150, 50, 150, 30);
        l2.setBounds(50, 100, 100, 30);
        t2.setBounds(150, 100, 150, 30);
        b.setBounds(120, 160, 100, 30);

        // Add Components
        f.add(l1);
        f.add(t1);
        f.add(l2);
        f.add(t2);
        f.add(b);

        // Set Layout
        f.setLayout(null);

        // Set Frame Size
        f.setSize(400, 300);

        // Make Frame Visible
        f.setVisible(true);

        // Button Action
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/test",
                            "root",
                            "");
                    PreparedStatement ps = con.prepareStatement(
                            "insert into register values(?,?)");
                    ps.setString(1, t1.getText());
                    ps.setString(2, t2.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(f,
                            "Registration Successful");
                    con.close();
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }
        });
    }
}
