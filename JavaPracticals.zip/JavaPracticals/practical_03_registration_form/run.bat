@echo off
if not exist mysql-connector-j-8.0.33.jar curl -L -o mysql-connector-j-8.0.33.jar https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar
mysql -u root < schema.sql || echo Could not run schema.sql. Run it in MySQL by hand.
javac RegistrationForm.java && java -cp ".;mysql-connector-j-8.0.33.jar" RegistrationForm
pause
