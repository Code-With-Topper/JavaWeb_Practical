Practical 3: Swing Registration Form
Needs: JDK + MySQL running (user root, empty password, as in the manual).
Run: double-click run.bat (Windows)  or  sh run.sh (Linux/Mac)
The script downloads the MySQL jar and runs schema.sql (the manual's table).
If "mysql" is not in your PATH, run schema.sql yourself in MySQL first.
Different MySQL password? Change it in RegistrationForm.java.
