import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class GradeServlet extends HttpServlet {
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws ServletException, IOException {
        // Read marks
        int m1 = Integer.parseInt(request.getParameter("m1"));
        int m2 = Integer.parseInt(request.getParameter("m2"));

        // Calculate total
        int total = m1 + m2;

        // Calculate percentage
        int per = total / 2;

        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        // Display result
        if (per >= 40) {
            out.println("<h1 style='color:green'>PASS</h1>");
        } else {
            out.println("<h1 style='color:red'>FAIL</h1>");
        }
    }
}
