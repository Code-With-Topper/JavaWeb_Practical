Practical 5: Grading (pass = 40 percent)
Needs: JDK 8+ and Maven.
Run: double-click run.bat  (Windows)   or   sh run.sh  (Linux/Mac)
Open in browser: http://localhost:8080/grade-servlet/
Stop: press Ctrl+C
