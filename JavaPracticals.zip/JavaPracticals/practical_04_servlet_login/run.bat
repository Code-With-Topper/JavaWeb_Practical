@echo off
mvn jetty:run
pause
