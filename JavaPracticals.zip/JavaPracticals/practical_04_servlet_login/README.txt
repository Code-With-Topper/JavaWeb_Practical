Practical 4: Servlet Login (admin / 123)
Needs: JDK 8+ and Maven.
Run: double-click run.bat  (Windows)   or   sh run.sh  (Linux/Mac)
Open in browser: http://localhost:8080/login-servlet/
Stop: press Ctrl+C
