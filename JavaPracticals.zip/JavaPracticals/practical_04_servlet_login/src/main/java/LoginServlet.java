import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get username from form
        String user = request.getParameter("username");

        // Get password from form
        String pass = request.getParameter("password");

        // Create output object
        PrintWriter out = response.getWriter();

        // Check login
        if (user.equals("admin") && pass.equals("123")) {
            out.println("Login Successful");
        } else {
            out.println("Invalid User");
        }
    }
}
