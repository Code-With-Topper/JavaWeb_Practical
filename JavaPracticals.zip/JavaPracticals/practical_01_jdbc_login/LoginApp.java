import java.sql.*; // Import SQL package

public class LoginApp {
    public static void main(String args[]) {
        try {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Create Connection with MySQL database
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/test",
                    "root",
                    "");

            // User input values
            String uname = "admin";
            String pass = "1234";

            // SQL Query using PreparedStatement
            PreparedStatement ps = con.prepareStatement(
                    "select * from users where username=? and password=?");

            // Set username value
            ps.setString(1, uname);

            // Set password value
            ps.setString(2, pass);

            // Execute query
            ResultSet rs = ps.executeQuery();

            // Check login success
            if (rs.next()) {
                System.out.println("Successful Login");
            } else {
                System.out.println("Invalid Username and Password");
            }

            // Close connection
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
