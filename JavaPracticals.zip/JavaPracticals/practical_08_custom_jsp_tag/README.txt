Practical 8: Custom JSP Tag (shows: Welcome Student)
Needs: JDK 8+ and Maven.
Run: double-click run.bat  (Windows)   or   sh run.sh  (Linux/Mac)
Open in browser: http://localhost:8080/jsp-tag/
Stop: press Ctrl+C
