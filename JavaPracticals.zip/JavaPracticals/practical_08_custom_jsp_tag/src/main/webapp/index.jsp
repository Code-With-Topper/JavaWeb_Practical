<%@ taglib uri="/WEB-INF/hello.tld" prefix="my" %>
<html>
<head><title>Custom Tag</title></head>
<body>
  <h2>Custom JSP Tag</h2>
  <my:hello/>
</body>
</html>
