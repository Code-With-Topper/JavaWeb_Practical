package tags; // package is needed so JSP can find the class

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public class HelloTag extends TagSupport {
    public int doStartTag() throws JspException {
        try {
            // Print message
            pageContext.getOut().println("Welcome Student");
        } catch (Exception e) {
            System.out.println(e);
        }
        return SKIP_BODY;
    }
}
