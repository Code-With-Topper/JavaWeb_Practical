import java.sql.*;

public class StudentInfo {
    public static void main(String args[]) {
        try {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Database Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/test",
                    "root",
                    "");

            // Insert Record
            PreparedStatement ps1 = con.prepareStatement(
                    "insert into student values(?,?)");
            ps1.setInt(1, 1);
            ps1.setString(2, "Rahul");
            ps1.executeUpdate();
            System.out.println("Record Inserted");

            // Update Record
            PreparedStatement ps2 = con.prepareStatement(
                    "update student set name=? where student_id=?");
            ps2.setString(1, "Amit");
            ps2.setInt(2, 1);
            ps2.executeUpdate();
            System.out.println("Record Updated");

            // Delete Record
            PreparedStatement ps3 = con.prepareStatement(
                    "delete from student where student_id=?");
            ps3.setInt(1, 1);
            ps3.executeUpdate();
            System.out.println("Record Deleted");

            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
