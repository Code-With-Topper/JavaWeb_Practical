#!/bin/sh
JAR=mysql-connector-j-8.0.33.jar
[ -f $JAR ] || curl -L -o $JAR https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar
mysql -u root < schema.sql || echo "Could not run schema.sql. Run it in MySQL by hand."
javac StudentInfo.java && java -cp ".:$JAR" StudentInfo
